module.exports = {
    MODE: "tdm",
    HUNT: true,
    TEAMS: 2
};