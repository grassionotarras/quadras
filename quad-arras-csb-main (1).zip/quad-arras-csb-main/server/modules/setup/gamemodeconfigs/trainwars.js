module.exports = {
    TRAIN: true,
};